"""
train_lstm_classifier.py
=========================
Model LSTM KLASIFIKASI sungguhan (5 kelas: Optimal, Agak Panas, Terlalu
Panas, Kurang Lembap, Terlalu Lembap) -- BEDA dari train_lstm.py yang
dipakai untuk grafik prediksi dashboard (itu regresi angka, bukan
klasifikasi kategori).

Script ini dibuat supaya angka accuracy di skripsi (Tabel 4.6) punya
bukti nyata: model benar-benar dilatih, dievaluasi pada data yang TIDAK
dipakai untuk melatih (test set), dan menghasilkan confusion matrix asli
-- bukan estimasi.

Alur:
1. Ambil seluruh histori suhu & kelembapan dari Firebase.
2. Beri label tiap baris pakai aturan classify() yang sama dengan
   script.js (ini caranya label "aktual" didapat -- sesuai Bab III).
3. Normalisasi (Min-Max) lalu susun jadi sequence sliding window
   (ukuran window = 5, sesuai Bab 4.c skripsi).
4. Bagi data berurutan waktu (BUKAN acak) menjadi data latih (80%) dan
   data uji (20%) -- supaya evaluasi jujur, model dites pada data yang
   belum pernah dilihat saat training.
5. Latih model LSTM dengan output Dense(5, softmax).
6. Evaluasi pada data uji: accuracy, confusion matrix, classification
   report (precision/recall/f1 per kelas) -- inilah angka yang BISA
   dipertanggungjawabkan untuk Tabel 4.6.
7. Simpan semua hasil ke lstm_classifier_hasil_evaluasi.txt supaya bisa
   langsung disalin ke skripsi dan ditunjukkan saat sidang.

Jalankan:
    python train_lstm_classifier.py --plant tanaman1
"""

import argparse
import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.utils import to_categorical

from train_lstm import fetch_all_logs, logs_to_dataframe, FEATURES

WINDOW = 5  # sesuai Bab 4.c skripsi: "ukuran window sebesar 5"
CLASSES = ["Terlalu Panas", "Agak Panas", "Terlalu Lembap", "Kurang Lembap", "Optimal"]


def filter_date_range(df, start, end):
    """Batasi data hanya pada rentang tanggal [start, end] (format YYYY-MM-DD, inklusif)."""
    if not start and not end:
        return df
    tanggal = df["timestamp"].str.slice(0, 10)
    mask = pd.Series(True, index=df.index)
    if start:
        mask &= tanggal >= start
    if end:
        mask &= tanggal <= end
    return df[mask].reset_index(drop=True)


def classify_row(suhu, kelembapan):
    """
    Aturan pelabelan -- SAMA PERSIS dengan classify() di script.js,
    supaya label "aktual" yang dipakai untuk melatih & mengevaluasi
    model ini konsisten dengan yang dijelaskan di Bab III skripsi.
    """
    if suhu > 35:
        return "Terlalu Panas"
    if suhu >= 27:
        return "Agak Panas"
    if kelembapan > 90:
        return "Terlalu Lembap"
    if kelembapan < 60:
        return "Kurang Lembap"
    return "Optimal"


def make_sequences_classification(scaled_values, labels_idx, window):
    """Sequence X (window langkah) -> label kelas pada langkah terakhir."""
    X, y = [], []
    for i in range(len(scaled_values) - window):
        X.append(scaled_values[i:i + window])
        y.append(labels_idx[i + window])  # label pada titik yang diprediksi
    return np.array(X), np.array(y)


def build_classifier(window, n_features, n_classes):
    model = keras.Sequential([
        layers.Input(shape=(window, n_features)),
        layers.LSTM(64, return_sequences=True),
        layers.LSTM(32),
        layers.Dense(16, activation="relu"),
        layers.Dense(n_classes, activation="softmax"),
    ])
    model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plant", default="tanaman1")
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--train_ratio", type=float, default=0.8,
                     help="Proporsi data latih (sisanya data uji). Default 80:20.")
    ap.add_argument("--start", default=None, help="Tanggal mulai (YYYY-MM-DD), contoh: 2026-06-01")
    ap.add_argument("--end", default=None, help="Tanggal akhir (YYYY-MM-DD), contoh: 2026-07-01")
    args = ap.parse_args()

    print("Mengambil data historis dari Firebase...")
    raw = fetch_all_logs()
    df = logs_to_dataframe(raw, args.plant)
    if args.start or args.end:
        before = len(df)
        df = filter_date_range(df, args.start, args.end)
        print(f"Filter tanggal {args.start or '...'} s.d. {args.end or '...'}: {before} -> {len(df)} baris")
    n_total = len(df)
    print(f"Total baris data: {n_total}")
    if n_total < WINDOW + 20:
        raise SystemExit(f"Data terlalu sedikit ({n_total} baris) untuk melatih & menguji model klasifikasi.")

    # 1) Label tiap baris memakai aturan classify() (label "aktual")
    df["label"] = df.apply(lambda r: classify_row(r["suhu"], r["kelembapan"]), axis=1)
    label_to_idx = {c: i for i, c in enumerate(CLASSES)}
    labels_idx = df["label"].map(label_to_idx).values

    print("\nDistribusi label aktual (sebelum windowing):")
    for c in CLASSES:
        n = int((df["label"] == c).sum())
        pct = 100 * n / n_total
        print(f"  {c:15s}: {n:6d} ({pct:.2f}%)")

    # 2) Normalisasi fitur input (suhu, kelembapan)
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(df[FEATURES].values)

    # 3) Susun jadi sequence sliding window
    X, y_idx = make_sequences_classification(scaled, labels_idx, WINDOW)
    y_onehot = to_categorical(y_idx, num_classes=len(CLASSES))
    print(f"\nTotal sampel time-series setelah sliding window (WINDOW={WINDOW}): {len(X)}")

    # 4) Split BERURUTAN waktu (bukan acak) -- konsisten dengan Bab 4.c
    split = int(len(X) * args.train_ratio)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y_onehot[:split], y_onehot[split:]
    y_test_idx = y_idx[split:]
    print(f"Data latih : {len(X_train)} sampel")
    print(f"Data uji   : {len(X_test)} sampel  <- INI yang dipakai untuk evaluasi accuracy")

    # 5) Latih model
    model = build_classifier(WINDOW, len(FEATURES), len(CLASSES))
    model.summary()
    early_stop = keras.callbacks.EarlyStopping(monitor="val_loss", patience=8, restore_best_weights=True)
    model.fit(
        X_train, y_train,
        validation_split=0.15,
        epochs=args.epochs,
        batch_size=32,
        callbacks=[early_stop],
        verbose=2,
    )

    # 6) Evaluasi JUJUR: hanya pada data uji (test set), bukan data latih
    y_pred_prob = model.predict(X_test, verbose=0)
    y_pred_idx = np.argmax(y_pred_prob, axis=1)

    n_benar = int(np.sum(y_pred_idx == y_test_idx))
    n_salah = int(len(y_test_idx) - n_benar)

    # Simpan model & hasil INTI dulu (sebelum bikin laporan teks), supaya
    # kalau ada error di bagian classification_report, model yang sudah
    # susah payah dilatih tidak hilang dan tidak perlu training ulang.
    model.save("lstm_classifier_model.keras")
    with open("lstm_classifier_hasil_evaluasi.json", "w", encoding="utf-8") as f:
        json.dump({
            "plant": args.plant,
            "window": WINDOW,
            "total_samples": len(X),
            "train_samples": len(X_train),
            "test_samples": len(X_test),
            "n_benar": n_benar,
            "n_salah": n_salah,
            "accuracy": round(float(acc), 4),
            "confusion_matrix": cm.tolist(),
            "classes": CLASSES,
        }, f, indent=2, ensure_ascii=False)
    print(f"\n[Model & hasil inti sudah tersimpan] Accuracy = {acc:.4f} ({n_benar}/{len(y_test_idx)} benar)")

    try:
        report = classification_report(
            y_test_idx, y_pred_idx,
            labels=list(range(len(CLASSES))),
            target_names=CLASSES,
            digits=4,
            zero_division=0,
        )
    except Exception as e:
        report = f"(Gagal membuat classification_report: {e})"

    hasil = []
    hasil.append("HASIL EVALUASI MODEL LSTM KLASIFIKASI (DATA UJI / TEST SET)")
    hasil.append("=" * 60)
    hasil.append(f"Tanaman                 : {args.plant}")
    hasil.append(f"Ukuran window           : {WINDOW}")
    hasil.append(f"Total sampel time-series: {len(X)}")
    hasil.append(f"Data latih (train)      : {len(X_train)} sampel ({args.train_ratio*100:.0f}%)")
    hasil.append(f"Data uji (test)         : {len(X_test)} sampel ({(1-args.train_ratio)*100:.0f}%)")
    hasil.append("")
    hasil.append(f"Jumlah data uji diklasifikasikan BENAR : {n_benar}")
    hasil.append(f"Jumlah data uji diklasifikasikan SALAH : {n_salah}")
    hasil.append(f"Accuracy = {n_benar} / {len(y_test_idx)} = {acc:.4f}  ({acc*100:.2f}%)")
    hasil.append("")
    hasil.append("Confusion Matrix (baris = label aktual, kolom = label prediksi):")
    header = "                 " + "  ".join(f"{c[:12]:>12s}" for c in CLASSES)
    hasil.append(header)
    for i, row in enumerate(cm):
        hasil.append(f"{CLASSES[i]:15s}  " + "  ".join(f"{v:12d}" for v in row))
    hasil.append("")
    hasil.append("Classification Report (precision / recall / f1-score per kelas):")
    hasil.append(report)

    output_text = "\n".join(hasil)
    print("\n" + output_text)

    with open("lstm_classifier_hasil_evaluasi.txt", "w", encoding="utf-8") as f:
        f.write(output_text)

    print("\nSelesai. Hasil tersimpan di:")
    print("  - lstm_classifier_hasil_evaluasi.txt  (langsung bisa disalin ke skripsi)")
    print("  - lstm_classifier_hasil_evaluasi.json")
    print("  - lstm_classifier_model.keras")


if __name__ == "__main__":
    main()