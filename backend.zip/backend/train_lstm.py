"""
train_lstm.py
=============
Melatih model LSTM untuk memprediksi suhu & kelembapan greenhouse
beberapa langkah waktu ke depan, berdasarkan data historis di Firebase.

Alur (sesuai diagram: Data historis -> Preprocessing -> Model LSTM):
1. Ambil semua data dari greenhouse/logs/{tanggal}/{jam} di Firebase
   untuk satu tanaman (default: tanaman1)
2. Urutkan berdasarkan waktu -> jadi satu deret waktu (time-series)
3. Normalisasi (MinMaxScaler 0-1) lalu dipecah jadi sequence
   (WINDOW langkah terakhir -> prediksi langkah berikutnya)
4. Latih model LSTM 2 lapis
5. Simpan model (.keras) dan scaler (.save) untuk dipakai app.py

Cara pakai:
    pip install -r requirements.txt
    python train_lstm.py --plant tanaman1

Catatan: Firebase Realtime Database Anda harus bisa diakses tanpa
auth (read public) seperti yang sudah dipakai di script.js Anda.
Jika sudah diberi rules private, tambahkan token/API key di sini.
"""

import argparse
import numpy as np
import pandas as pd
import requests
import joblib
from sklearn.preprocessing import MinMaxScaler
from tensorflow import keras
from tensorflow.keras import layers

FB_HOST = "greenhouse-2c990-default-rtdb.asia-southeast1.firebasedatabase.app"
WINDOW = 6          # pakai 6 pembacaan terakhir untuk memprediksi 1 langkah berikutnya
FEATURES = ["suhu", "kelembapan"]  # kolom yang diprediksi


def fetch_all_logs():
    """Ambil seluruh node greenhouse/logs dari Firebase (semua tanggal & jam)."""
    url = f"https://{FB_HOST}/greenhouse/logs.json"
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    return r.json() or {}


def logs_to_dataframe(raw, plant):
    """
    Ratakan struktur Firebase (tanggal -> jam -> {suhu, kelembapan, ...})
    jadi satu DataFrame terurut waktu untuk satu tanaman.
    Mendukung struktur greenhouse/logs/{tanggal}/{jam}/{suhu,...}
    maupun greenhouse/logs/{tanggal}/{jam}/{tanaman}/{suhu,...}.
    """
    rows = []
    for tanggal, jam_dict in (raw or {}).items():
        if not isinstance(jam_dict, dict):
            continue
        for jam, val in jam_dict.items():
            if not isinstance(val, dict):
                continue
            rec = val if ("suhu" in val or "kelembapan" in val) else val.get(plant)
            if not rec or not isinstance(rec, dict):
                continue
            if "suhu" not in rec or "kelembapan" not in rec:
                continue
            rows.append({
                "timestamp": f"{tanggal} {jam}",
                "suhu": float(rec["suhu"]),
                "kelembapan": float(rec["kelembapan"]),
            })
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df = df.sort_values("timestamp").reset_index(drop=True)
    return df


def make_sequences(values, window):
    """Ubah deret nilai jadi pasangan (X, y) untuk supervised learning."""
    X, y = [], []
    for i in range(len(values) - window):
        X.append(values[i:i + window])
        y.append(values[i + window])
    return np.array(X), np.array(y)


def build_model(window, n_features):
    model = keras.Sequential([
        layers.Input(shape=(window, n_features)),
        layers.LSTM(64, return_sequences=True),
        layers.LSTM(32),
        layers.Dense(16, activation="relu"),
        layers.Dense(n_features),  # output: prediksi suhu & kelembapan langkah berikutnya
    ])
    model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plant", default="tanaman1")
    ap.add_argument("--epochs", type=int, default=60)
    args = ap.parse_args()

    print(f"Mengambil data historis untuk {args.plant} dari Firebase...")
    raw = fetch_all_logs()
    df = logs_to_dataframe(raw, args.plant)
    print(f"Total data terkumpul: {len(df)} baris")

    if len(df) < WINDOW + 10:
        raise SystemExit(
            f"Data terlalu sedikit ({len(df)} baris). "
            f"Butuh minimal {WINDOW + 10} baris log di Firebase untuk melatih LSTM. "
            "Kumpulkan data sensor lebih lama dulu, lalu jalankan ulang script ini."
        )

    values = df[FEATURES].values

    # Preprocessing: normalisasi 0-1 (wajib untuk LSTM agar training stabil)
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(values)

    X, y = make_sequences(scaled, WINDOW)
    split = int(len(X) * 0.85)
    X_train, X_val = X[:split], X[split:]
    y_train, y_val = y[:split], y[split:]

    model = build_model(WINDOW, len(FEATURES))
    model.summary()

    early_stop = keras.callbacks.EarlyStopping(
        monitor="val_loss", patience=8, restore_best_weights=True
    )
    model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val) if len(X_val) else None,
        epochs=args.epochs,
        batch_size=16,
        callbacks=[early_stop] if len(X_val) else [],
        verbose=2,
    )

    model.save("lstm_model.keras")
    joblib.dump(scaler, "scaler.save")
    joblib.dump({"window": WINDOW, "features": FEATURES, "plant": args.plant}, "meta.save")
    print("Selesai. Model tersimpan: lstm_model.keras, scaler.save, meta.save")


if __name__ == "__main__":
    main()
