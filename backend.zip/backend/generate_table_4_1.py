"""
generate_table_4_1.py
======================
Menghasilkan ulang seluruh angka yang bergantung pada rincian HARIAN
data sensor (Tabel 4.1, jumlah hari pengamatan, tanggal yang bolong,
serta nilai suhu minimum/maksimum keseluruhan yang dipakai di contoh
perhitungan normalisasi Bab 4.b) -- dihitung dari SELURUH data terbaru
di Firebase, bukan lagi data lama (35.029 baris / 28 hari).

Jalankan:
    python generate_table_4_1.py --plant tanaman1
"""

import argparse
from datetime import datetime, timedelta
import pandas as pd

from train_lstm import fetch_all_logs, logs_to_dataframe
from train_lstm_classifier import filter_date_range

HARI_ID = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plant", default="tanaman1")
    ap.add_argument("--start", default=None, help="Tanggal mulai (YYYY-MM-DD), contoh: 2026-06-01")
    ap.add_argument("--end", default=None, help="Tanggal akhir (YYYY-MM-DD), contoh: 2026-07-01")
    args = ap.parse_args()

    print("Mengambil data historis dari Firebase...")
    raw = fetch_all_logs()
    df = logs_to_dataframe(raw, args.plant)
    if args.start or args.end:
        before = len(df)
        df = filter_date_range(df, args.start, args.end)
        print(f"Filter tanggal {args.start or '...'} s.d. {args.end or '...'}: {before} -> {len(df)} baris")
    df["tanggal"] = df["timestamp"].str.slice(0, 10)
    n_total = len(df)
    print(f"Total baris data: {n_total}\n")

    # ---- Tabel 4.1: rincian per hari ----
    rows_out = []
    for tanggal, g in df.groupby("tanggal", sort=True):
        d = datetime.strptime(tanggal, "%Y-%m-%d")
        hari = HARI_ID[d.weekday()]
        n = len(g)
        smin, smax = g["suhu"].min(), g["suhu"].max()
        savg = g["suhu"].mean()
        havg = g["kelembapan"].mean()
        d_fmt = d.strftime("%d-%m-%Y")
        rows_out.append(
            f"  {d_fmt}    {hari:<8s}   {n:6d}      {smin:.1f} -- {smax:.1f}    {savg:.2f}      {havg:.2f}"
        )

    print("=" * 90)
    print("TABEL 4.1 -- RINCIAN DATA PER HARI (salin ke skripsi)")
    print("Tanggal        Hari        Jumlah Data   Suhu Min-Maks   Rata Suhu   Rata Kelembapan")
    print("\n".join(rows_out))
    print("=" * 90)

    # ---- Rentang tanggal & hari yang bolong ----
    tanggal_ada = sorted(df["tanggal"].unique())
    first_d = datetime.strptime(tanggal_ada[0], "%Y-%m-%d")
    last_d = datetime.strptime(tanggal_ada[-1], "%Y-%m-%d")
    semua_tanggal = set()
    cur = first_d
    while cur <= last_d:
        semua_tanggal.add(cur.strftime("%Y-%m-%d"))
        cur += timedelta(days=1)
    tanggal_bolong = sorted(semua_tanggal - set(tanggal_ada))
    tanggal_bolong_fmt = [datetime.strptime(t, "%Y-%m-%d").strftime("%d %B %Y") for t in tanggal_bolong]

    print(f"\nRentang tanggal   : {first_d.strftime('%d %B %Y')} s.d. {last_d.strftime('%d %B %Y')}")
    print(f"Jumlah hari (kalender, termasuk yang bolong) : {(last_d - first_d).days + 1} hari")
    print(f"Jumlah hari yang ADA datanya                 : {len(tanggal_ada)} hari")
    if tanggal_bolong_fmt:
        print(f"Tanggal TIDAK ADA data (bolong)              : {', '.join(tanggal_bolong_fmt)}")
    else:
        print("Tanggal TIDAK ADA data (bolong)              : tidak ada, data lengkap tiap hari")

    # ---- Nilai suhu minimum/maksimum keseluruhan (dipakai di contoh normalisasi Bab 4.b) ----
    suhu_min = df["suhu"].min()
    suhu_max = df["suhu"].max()
    print(f"\nSuhu MINIMUM keseluruhan data  : {suhu_min:.1f}°C")
    print(f"Suhu MAKSIMUM keseluruhan data : {suhu_max:.1f}°C")
    print("(Dua nilai ini dipakai untuk mengganti 21,2°C dan 41,8°C")
    print(" di kalimat narasi Bab 4 dan contoh perhitungan Min-Max Scaling)")

    with open("tabel_4_1_dan_ringkasan.txt", "w", encoding="utf-8") as f:
        f.write("TABEL 4.1\n")
        f.write("Tanggal        Hari        Jumlah Data   Suhu Min-Maks   Rata Suhu   Rata Kelembapan\n")
        f.write("\n".join(rows_out))
        f.write(f"\n\nRentang tanggal: {first_d.strftime('%d %B %Y')} s.d. {last_d.strftime('%d %B %Y')}\n")
        f.write(f"Jumlah hari kalender: {(last_d - first_d).days + 1}\n")
        f.write(f"Jumlah hari ada data: {len(tanggal_ada)}\n")
        f.write(f"Tanggal bolong: {', '.join(tanggal_bolong_fmt) if tanggal_bolong_fmt else '(tidak ada)'}\n")
        f.write(f"Suhu minimum keseluruhan: {suhu_min:.1f}\n")
        f.write(f"Suhu maksimum keseluruhan: {suhu_max:.1f}\n")

    print("\nSelesai. Semua hasil di atas juga tersimpan di: tabel_4_1_dan_ringkasan.txt")
    print("Kirim isi file itu (atau copy-paste output di atas) ke chat untuk saya masukkan ke skripsi.")


if __name__ == "__main__":
    main()