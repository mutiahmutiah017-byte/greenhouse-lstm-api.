"""
evaluate_full_data.py
======================
Mengevaluasi model LSTM klasifikasi (yang sudah dilatih lewat
train_lstm_classifier.py) pada SELURUH data, sesuai rumus (4.8) di
skripsi: Accuracy = (jumlah data diklasifikasikan benar) / (jumlah
seluruh data) -- TANPA konsep data latih/data uji terpisah.

Tidak perlu training ulang -- model yang sudah tersimpan
(lstm_classifier_model.keras) langsung dipakai untuk memprediksi ulang
seluruh data, lalu dibandingkan dengan label aktual (hasil pelabelan
rule-based pada Tabel 4.4).

Jalankan:
    python evaluate_full_data.py --plant tanaman1
"""

import argparse
import json
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from tensorflow import keras

from train_lstm import fetch_all_logs, logs_to_dataframe, FEATURES
from train_lstm_classifier import classify_row, make_sequences_classification, filter_date_range, WINDOW, CLASSES


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plant", default="tanaman1")
    ap.add_argument("--start", default=None, help="Tanggal mulai (YYYY-MM-DD), contoh: 2026-06-01")
    ap.add_argument("--end", default=None, help="Tanggal akhir (YYYY-MM-DD), contoh: 2026-07-01")
    args = ap.parse_args()

    print("Mengambil data historis dari Firebase...")
    raw = fetch_all_logs()
    df = logs_to_dataframe(raw, args.plant)
    if args.start or args.end:
        before = len(df)
        df = filter_date_range(df, args.start, args.end)
        print(f"Filter tanggal {args.start or '...'} s.d. {args.end or '...'}: {before} -> {len(df)} baris")
    n_total = len(df)
    print(f"Total baris data: {n_total}")

    df["label"] = df.apply(lambda r: classify_row(r["suhu"], r["kelembapan"]), axis=1)
    label_to_idx = {c: i for i, c in enumerate(CLASSES)}
    labels_idx = df["label"].map(label_to_idx).values

    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(df[FEATURES].values)

    X, y_idx = make_sequences_classification(scaled, labels_idx, WINDOW)
    print(f"Total sampel time-series (WINDOW={WINDOW}): {len(X)}")

    print("Memuat model yang sudah dilatih (lstm_classifier_model.keras)...")
    model = keras.models.load_model("lstm_classifier_model.keras")

    print("Memprediksi seluruh data...")
    y_pred_prob = model.predict(X, verbose=0)
    y_pred_idx = np.argmax(y_pred_prob, axis=1)

    acc = accuracy_score(y_idx, y_pred_idx)
    cm = confusion_matrix(y_idx, y_pred_idx, labels=list(range(len(CLASSES))))
    report = classification_report(
        y_idx, y_pred_idx,
        labels=list(range(len(CLASSES))),
        target_names=CLASSES,
        digits=4,
        zero_division=0,
    )

    n_benar = int(np.sum(y_pred_idx == y_idx))
    n_salah = int(len(y_idx) - n_benar)

    hasil = []
    hasil.append("HASIL EVALUASI MODEL LSTM KLASIFIKASI (SELURUH DATA, SESUAI RUMUS 4.8)")
    hasil.append("=" * 70)
    hasil.append(f"Tanaman                 : {args.plant}")
    hasil.append(f"Ukuran window           : {WINDOW}")
    hasil.append(f"Jumlah seluruh data     : {len(X)} sampel")
    hasil.append("")
    hasil.append(f"Jumlah data diklasifikasikan BENAR : {n_benar}")
    hasil.append(f"Jumlah data diklasifikasikan SALAH : {n_salah}")
    hasil.append(f"Accuracy = {n_benar} / {len(y_idx)} = {acc:.4f}  ({acc*100:.2f}%)")
    hasil.append("")
    hasil.append("Confusion Matrix (baris = label aktual, kolom = label prediksi):")
    header = "                 " + "  ".join(f"{c[:12]:>12s}" for c in CLASSES)
    hasil.append(header)
    for i, row in enumerate(cm):
        hasil.append(f"{CLASSES[i]:15s}  " + "  ".join(f"{v:12d}" for v in row))
    hasil.append("")
    hasil.append("Classification Report (precision / recall / f1-score per kelas):")
    hasil.append(report)

    output_text = "\n".join(hasil)
    print("\n" + output_text)

    with open("lstm_classifier_hasil_evaluasi_seluruh_data.txt", "w", encoding="utf-8") as f:
        f.write(output_text)
    with open("lstm_classifier_hasil_evaluasi_seluruh_data.json", "w", encoding="utf-8") as f:
        json.dump({
            "plant": args.plant,
            "window": WINDOW,
            "total_samples": len(X),
            "n_benar": n_benar,
            "n_salah": n_salah,
            "accuracy": round(float(acc), 4),
            "confusion_matrix": cm.tolist(),
            "classes": CLASSES,
        }, f, indent=2, ensure_ascii=False)

    print("\nSelesai. Hasil tersimpan di: lstm_classifier_hasil_evaluasi_seluruh_data.txt")


if __name__ == "__main__":
    main()